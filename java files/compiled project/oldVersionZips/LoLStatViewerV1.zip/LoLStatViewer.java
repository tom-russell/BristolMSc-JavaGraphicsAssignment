import java.util.*;
import java.io.IOException;
import javafx.application.*;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.geometry.Pos;
import javafx.event.ActionEvent;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class LoLStatViewer extends Application
{
    private RiotAPIData api;
    private BorderPane root;
    
    // UI Element Objects
    private Label champName;
    private ImageView bigImage;
    private Label champTitle;
    private TilePane champGrid;
    
    private List<String> champKeys;
    
    
    @Override
    public void start(Stage stage)
    {
        root = new BorderPane();
        api = new RiotAPIData();
        champKeys = api.GetKeys();
        
        // Initialise all the UI elements
        InitLeftPanel();
        InitMainPanel();
        
        // Set up and show the JavaFX scene and stage
        stage.setTitle("LoL Champion Viewer");
        stage.setScene(new Scene(root, 700, 600));
        stage.show();
    }
    
    // Initialse the left panel, with the larger image and additional details. On startup the left
    // panel displays the first champion (alphabetically)
    private void InitLeftPanel()
    {
        VBox leftPanel = new VBox();
        root.setLeft(leftPanel);
        
        champName = new Label();
        bigImage = new ImageView();
        champTitle = new Label();
        
        UpdateLeftPanel(champKeys.get(0));
        leftPanel.getChildren().addAll(champName, bigImage, champTitle);
    }
    
    // Initialise the central/main panel with the champion grid. Structured as a tilepane within add
    // scrollpane.
    private void InitMainPanel()
    {
        ScrollPane scrollPane = new ScrollPane();
        root.setCenter(scrollPane);
        
        champGrid = new TilePane();
        champGrid.setPrefCols(5);
        scrollPane.setContent(champGrid);
        
        PopulateGrid(champGrid);
    }
    
    // Fill the champion grid with buttons, each with the champion portrait & name displayed
    private void PopulateGrid(TilePane champGrid)
    {
        // Retrieve the correct version base image url
        String baseUrl = api.GetImageUrl(true);
        
        // Loop through each champion key, add a button and set the image & text for each
        for (String key : champKeys)
        {
            
            Button champ = new Button();
            
            String imageUrl = baseUrl + "img/champion/" + key +".png";
            Image cImage = new Image(baseUrl + "img/champion/" + key +".png");
            
            champ.setText(api.GetDetails(key).get("name").toString());
            champ.setGraphic(new ImageView(cImage));
            champ.setContentDisplay(ContentDisplay.TOP);
            champGrid.getChildren().add(champ);
            
            // Each button is given the relevant champion key as the ID, so that when a button is 
            // clicked it can be identified
            champ.setId(key);
            champ.setOnAction(this::ChampClicked);
        }
    }
    
    // When a champion button is clicked the left panel is updated with their details
    private void ChampClicked(ActionEvent event)
    {
        Button clicked = (Button) event.getSource();
        UpdateLeftPanel(clicked.getId());
    }
    
    // Update each of the UI elements & image in the 'details' left panel
    private void UpdateLeftPanel(String key)
    {
        Map<String,Object> champDetails = api.GetDetails(key);
        
        champName.setText(champDetails.get("name").toString());
        bigImage.setImage(new Image(api.GetImageUrl(false) + "img/champion/loading/" + key +"_0.jpg"));
        champTitle.setText("\"" + champDetails.get("title").toString() + "\"");
    }
}
